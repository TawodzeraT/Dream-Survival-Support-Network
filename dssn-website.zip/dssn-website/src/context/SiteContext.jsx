import React, { createContext, useContext, useState, useEffect } from 'react'
import {
  INITIAL_COUNTER,
  INITIAL_BLOG_POSTS,
  GALLERY_IMAGES,
  TEAM,
  PROGRAMS,
  SITE_CONFIG,
} from '../data/siteData'

const SiteContext = createContext(null)

export function SiteProvider({ children }) {
  // ── Counter ──
  const [counter, setCounter] = useState(() => {
    try {
      const saved = localStorage.getItem('dssn_counter')
      return saved ? JSON.parse(saved) : INITIAL_COUNTER
    } catch { return INITIAL_COUNTER }
  })

  // ── Blog Posts ──
  const [posts, setPosts] = useState(() => {
    try {
      const saved = localStorage.getItem('dssn_posts')
      return saved ? JSON.parse(saved) : INITIAL_BLOG_POSTS
    } catch { return INITIAL_BLOG_POSTS }
  })

  // ── Gallery ──
  const [gallery, setGallery] = useState(() => {
    try {
      const saved = localStorage.getItem('dssn_gallery')
      return saved ? JSON.parse(saved) : GALLERY_IMAGES
    } catch { return GALLERY_IMAGES }
  })

  // ── Team ──
  const [team, setTeam] = useState(() => {
    try {
      const saved = localStorage.getItem('dssn_team')
      return saved ? JSON.parse(saved) : TEAM
    } catch { return TEAM }
  })

  // ── Programs ──
  const [programs, setPrograms] = useState(() => {
    try {
      const saved = localStorage.getItem('dssn_programs')
      return saved ? JSON.parse(saved) : PROGRAMS
    } catch { return PROGRAMS }
  })

  // ── Persist to localStorage ──
  useEffect(() => {
    localStorage.setItem('dssn_counter', JSON.stringify(counter))
  }, [counter])

  useEffect(() => {
    localStorage.setItem('dssn_posts', JSON.stringify(posts))
  }, [posts])

  useEffect(() => {
    localStorage.setItem('dssn_gallery', JSON.stringify(gallery))
  }, [gallery])

  useEffect(() => {
    localStorage.setItem('dssn_team', JSON.stringify(team))
  }, [team])

  useEffect(() => {
    localStorage.setItem('dssn_programs', JSON.stringify(programs))
  }, [programs])

  // ── Blog CRUD ──
  const addPost = (post) => {
    const newPost = { ...post, id: Date.now(), date: new Date().toISOString().slice(0, 10) }
    setPosts(prev => [newPost, ...prev])
    return newPost
  }

  const updatePost = (id, updates) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p))
  }

  const deletePost = (id) => {
    setPosts(prev => prev.filter(p => p.id !== id))
  }

  // ── Gallery CRUD ──
  const addGalleryImage = (image) => {
    const newImg = { ...image, id: Date.now() }
    setGallery(prev => [newImg, ...prev])
  }

  const deleteGalleryImage = (id) => {
    setGallery(prev => prev.filter(img => img.id !== id))
  }

  // ── Team CRUD ──
  const addTeamMember = (member) => {
    setTeam(prev => [...prev, { ...member, id: Date.now() }])
  }

  const updateTeamMember = (id, updates) => {
    setTeam(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m))
  }

  const deleteTeamMember = (id) => {
    setTeam(prev => prev.filter(m => m.id !== id))
  }

  // ── Counter ──
  const updateCounter = (updates) => {
    setCounter(prev => ({ ...prev, ...updates }))
  }

  // ── Program update ──
  const updateProgram = (id, updates) => {
    setPrograms(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p))
  }

  return (
    <SiteContext.Provider value={{
      counter, updateCounter,
      posts, addPost, updatePost, deletePost,
      gallery, addGalleryImage, deleteGalleryImage,
      team, addTeamMember, updateTeamMember, deleteTeamMember,
      programs, updateProgram,
      siteConfig: SITE_CONFIG,
      // aliases for gallery used in admin
      addGalleryItem: addGalleryImage,
      deleteGalleryItem: deleteGalleryImage,
    }}>
      {children}
    </SiteContext.Provider>
  )
}

export const useSite = () => {
  const ctx = useContext(SiteContext)
  if (!ctx) throw new Error('useSite must be used within SiteProvider')
  return ctx
}
