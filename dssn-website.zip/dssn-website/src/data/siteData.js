// =============================================
// DSSN SITE DATA — Edit all content here
// =============================================

export const SITE_CONFIG = {
  name: "Dreamers and Survivors Support Network",
  short: "DSSN",
  tagline: "Together We Build Hope!",
  email: "info@dreamsupport.org",
  address: "3888 Winthrop Dr Lexington, KY, 40514",
  phone: "(859) 555-0194",
  social: {
    facebook: "https://facebook.com/dssnorg",
    twitter: "https://twitter.com/dssnorg",
    instagram: "https://instagram.com/dssnorg",
    linkedin: "https://linkedin.com/company/dssnorg",
  },
}

export const MISSION = {
  statement: "We empower underserved youth and families through digital access, educational support, and community-driven programs that turn dreams into reality.",
  vision: "A world where every student, regardless of background or circumstance, has the tools, mentorship, and opportunity to thrive.",
  values: [
    { title: "Equity", desc: "Every child deserves equal access to opportunity." },
    { title: "Community", desc: "Together we are stronger. Together we rise." },
    { title: "Innovation", desc: "We solve real problems with creative, scalable solutions." },
    { title: "Dignity", desc: "We serve with respect, compassion, and humility." },
  ],
}

// Initial counter — editable via Admin Panel
export const INITIAL_COUNTER = {
  laptops: 847,
  students: 2400,
  workshops: 65,
  scholarships: 130,
}

export const PROGRAMS = [
  {
    id: "digital-learning",
    title: "Digital Learning",
    icon: "💻",
    color: "#1a56db",
    tagline: "Bridging the Digital Divide",
    summary: "Providing refurbished laptops and internet access to students who lack the technology needed to compete in today's digital world.",
    description: `The Digital Learning Program is at the heart of DSSN's mission. We believe that in the 21st century, access to technology is not a luxury—it is a right. Yet millions of students across the country are left behind simply because they cannot afford a laptop or reliable internet.

Our program collects, refurbishes, and distributes high-quality laptops to students in K–12 schools and higher education who demonstrate financial need. Each device is loaded with essential educational software, safety filters, and productivity tools before delivery.

Beyond hardware, we partner with local internet providers to offer subsidized or free broadband access to qualifying families. We also run monthly Digital Skills Workshops, teaching students everything from basic computer literacy to coding fundamentals and cybersecurity awareness.

Since launching, we have distributed over 800 laptops and directly impacted thousands of students in the greater Kentucky region and beyond.`,
    stats: [
      { label: "Laptops Donated", value: "847+" },
      { label: "Students Reached", value: "2,400+" },
      { label: "Partner Schools", value: "34" },
    ],
    impact: "For every $40 donated, we can put a laptop in the hands of a student who needs it most.",
  },
  {
    id: "teacher-support",
    title: "Teacher Support",
    icon: "🏫",
    color: "#2563eb",
    tagline: "Empowering the Educators Who Change Lives",
    summary: "Providing professional development, classroom resources, and mental wellness support to teachers in under-resourced schools.",
    description: `Great teachers change lives. But too many educators in under-resourced schools work without adequate supplies, professional development opportunities, or emotional support systems.

DSSN's Teacher Support Program addresses this gap on multiple fronts. We run quarterly Professional Development Workshops where teachers learn new instructional strategies, technology integration techniques, and culturally responsive teaching methods.

We also provide classroom supply grants — direct funding for teachers to purchase the materials their students need but cannot afford. From science kits to art supplies to bookshelves, we help teachers build the classrooms students deserve.

Additionally, we partner with mental health professionals to offer educator wellness retreats and ongoing coaching, because a supported teacher is a more effective teacher. We recognize that teacher burnout is a crisis affecting our most vulnerable students most severely.`,
    stats: [
      { label: "Workshops Hosted", value: "65+" },
      { label: "Teachers Supported", value: "380+" },
      { label: "Grants Awarded", value: "$42K" },
    ],
    impact: "Your donation of $750 funds a full-day professional development workshop for an entire school staff.",
  },
  {
    id: "scholarships",
    title: "Scholarships",
    icon: "🎓",
    color: "#1d4ed8",
    tagline: "Investing in Tomorrow's Leaders",
    summary: "Merit and need-based scholarships for first-generation college students and youth from low-income households.",
    description: `The DSSN Scholarship Program believes that financial hardship should never be a barrier to higher education. We provide merit-and-need-based scholarships to qualifying students pursuing two-year or four-year degrees, vocational training, or professional certifications.

Our scholarships are designed specifically for students who are the first in their families to attend college, who have aged out of foster care, who are undocumented dreamers, or who have faced extraordinary personal adversity.

Beyond the financial award, every scholarship recipient is paired with a professional mentor in their field of study and receives ongoing academic advising, career coaching, and access to our network of alumni and professional supporters.

We believe that investing in one student's education has a multiplying effect — on their family, their community, and generations to come.`,
    stats: [
      { label: "Scholarships Awarded", value: "130+" },
      { label: "Avg. Award", value: "$2,500" },
      { label: "Graduation Rate", value: "89%" },
    ],
    impact: "A $500 donation contributes directly to our scholarship fund, changing a student's trajectory forever.",
  },
  {
    id: "college-readiness",
    title: "College Readiness",
    icon: "📚",
    color: "#1e40af",
    tagline: "Preparing Students for What's Ahead",
    summary: "Comprehensive test prep, college application support, and financial aid navigation for high school juniors and seniors.",
    description: `Getting into college is only half the battle — first, students must navigate the complex world of applications, standardized tests, personal statements, and financial aid.

The DSSN College Readiness Program provides end-to-end support for high school juniors and seniors from low-income backgrounds. Our certified college counselors work one-on-one with students to identify schools that are a good fit, craft compelling personal essays, and complete scholarship and FAFSA applications.

We host SAT/ACT prep courses throughout the year at no cost to students, with small class sizes and experienced instructors. Our College Visits Program organizes group trips to local and regional universities, giving students the chance to see campus life firsthand.

Through partnerships with community colleges and universities, we also host FAFSA completion workshops for families, ensuring that finances are never the reason a qualified student doesn't apply.`,
    stats: [
      { label: "Students Counseled", value: "520+" },
      { label: "College Acceptance Rate", value: "94%" },
      { label: "Avg. Aid Secured", value: "$18K" },
    ],
    impact: "Helping a student navigate college applications and financial aid can mean $10,000–$50,000 in secured funding.",
  },
  {
    id: "wellness",
    title: "Wellness",
    icon: "💙",
    color: "#1e3a8a",
    tagline: "Whole-Person Support for Whole-Community Healing",
    summary: "Mental health resources, trauma-informed care, and wellness programs for youth and families navigating hardship.",
    description: `Education and opportunity cannot flourish without a foundation of mental and emotional wellbeing. DSSN's Wellness Program addresses the whole person — not just the student's academic needs, but their psychological, social, and physical health.

We partner with licensed therapists, social workers, and community health workers to provide free or low-cost mental health counseling to youth and their families. Our trauma-informed approach recognizes that many of the students we serve have experienced significant adversity, including poverty, housing instability, family separation, and community violence.

Our Saturday Wellness Circles create safe, structured spaces for young people to share their experiences, build coping skills, and connect with peers who understand their journey. We also run a nutrition and fitness initiative, offering cooking classes, community garden access, and recreational activities at no cost.

Supporting wellness is not a "nice to have" — it is the foundation upon which all other success is built.`,
    stats: [
      { label: "Counseling Sessions", value: "1,200+" },
      { label: "Youth Enrolled", value: "340+" },
      { label: "Wellness Circles", value: "48" },
    ],
    impact: "Your gift of $100 funds two counseling sessions for a young person navigating trauma and hardship.",
  },
]

export const TEAM = [
  {
    id: 1,
    name: "Dr. Angela Worthington",
    title: "Founder & Executive Director",
    bio: "Dr. Worthington founded DSSN in 2017 after two decades in public education, witnessing firsthand the systemic barriers preventing talented students from reaching their potential. A survivor herself, she brings fierce compassion and relentless determination to every aspect of DSSN's work.",
    image: null,
    initials: "AW",
  },
  {
    id: 2,
    name: "Marcus Thompson",
    title: "Board Chair",
    bio: "Marcus brings 20+ years of nonprofit leadership and strategic planning expertise. He serves on multiple community boards and is a passionate advocate for educational equity and economic mobility for underserved youth.",
    image: null,
    initials: "MT",
  },
  {
    id: 3,
    name: "Priya Nair",
    title: "Director of Programs",
    bio: "Priya oversees all five DSSN program areas, ensuring alignment with the mission and measurable community impact. She holds a Master's in Social Work from the University of Kentucky and has managed educational initiatives for over 12 years.",
    image: null,
    initials: "PN",
  },
  {
    id: 4,
    name: "James Okafor",
    title: "Director of Technology",
    bio: "James leads DSSN's Digital Learning Program, managing laptop procurement, refurbishment, and distribution. A former software engineer, he now channels his skills toward closing the digital divide in under-resourced communities.",
    image: null,
    initials: "JO",
  },
  {
    id: 5,
    name: "Carmen Rivera",
    title: "Development & Outreach Manager",
    bio: "Carmen drives DSSN's fundraising strategy and community partnerships. She has secured over $1.2M in grants and donations for the organization and is beloved for her ability to connect donors deeply with DSSN's mission.",
    image: null,
    initials: "CR",
  },
  {
    id: 6,
    name: "Dr. Samuel Benson",
    title: "Board Treasurer",
    bio: "Dr. Benson is a CPA and financial consultant who ensures DSSN's fiscal health and transparency. His expertise in nonprofit finance has helped the organization maximize every dollar toward direct program delivery.",
    image: null,
    initials: "SB",
  },
]

export const DONATION_TIERS = [
  {
    id: "laptop1",
    amount: 40,
    label: "1 Laptop",
    icon: "💻",
    description: "Puts one refurbished laptop in the hands of a student who needs it most.",
    featured: false,
  },
  {
    id: "laptop2",
    amount: 100,
    label: "2 Laptops",
    icon: "💻💻",
    description: "Equips two students with the technology they need to learn and thrive.",
    featured: true,
  },
  {
    id: "bulk",
    amount: 600,
    label: "Bulk Shipment",
    icon: "📦",
    description: "Funds a bulk shipment of devices to a partner school or community center.",
    featured: false,
  },
  {
    id: "workshop",
    amount: 750,
    label: "Teacher Workshop",
    icon: "🏫",
    description: "Sponsors a full-day professional development workshop for an entire school staff.",
    featured: false,
  },
]

export const INITIAL_BLOG_POSTS = [
  {
    id: 1,
    title: "Over 800 Laptops Distributed — And We're Just Getting Started",
    slug: "800-laptops-distributed",
    category: "Impact",
    date: "2024-03-15",
    author: "Dr. Angela Worthington",
    excerpt: "What started as a grassroots effort to put a few laptops in students' hands has grown into a movement. We share our milestone story and what's next.",
    content: `When Dr. Angela Worthington packed her first 12 refurbished laptops into her car trunk in 2017, she had no idea it would become the seed of a movement that would change thousands of lives.

Today, DSSN has distributed over 800 laptops across 34 partner schools in Kentucky and neighboring states. The impact is real, measurable, and deeply personal — we hear from students who submitted college applications on their DSSN laptop, completed their first coding project, or simply did their homework without having to borrow a classmate's phone.

"Technology is the great equalizer when it's accessible," says Dr. Worthington. "But it's the deepest divider when it's not."

This milestone is not just a number. Each laptop represents a student who no longer has to stay late at a library to finish homework, who can now video-call a tutor, who has the same digital tools as their peers in wealthier districts.

We are setting our sights on 1,000 laptops by end of year. With your help, we'll get there.`,
    image: null,
    published: true,
  },
  {
    id: 2,
    title: "Meet Maria: A Scholarship Recipient's Journey to Medical School",
    slug: "maria-scholarship-journey",
    category: "Student Stories",
    date: "2024-02-28",
    author: "Carmen Rivera",
    excerpt: "Maria arrived in the U.S. at age 14 speaking no English. Today she's in her second year of medical school. DSSN was part of her path.",
    content: `Maria came to Lexington, Kentucky at 14, fleeing violence in her home country with her mother and younger brother. She spoke no English. She had no laptop, no internet, and no idea that the American education system would become her greatest ally.

A DSSN volunteer spotted Maria's potential at a community center and connected her with our Digital Learning and College Readiness programs. She received a refurbished laptop through our program, enrolled in our college prep workshops, and was awarded a DSSN scholarship to cover her first year at the University of Kentucky.

"DSSN didn't just give me a laptop," Maria says. "They gave me people who believed in me when I didn't know how to believe in myself."

Today Maria is in her second year of medical school, studying to become a pediatrician who serves immigrant communities. Her story is exactly why we do what we do.`,
    image: null,
    published: true,
  },
  {
    id: 3,
    title: "New Partnership Brings Digital Skills Workshops to 5 More Schools",
    slug: "new-partnership-digital-skills",
    category: "News",
    date: "2024-01-20",
    author: "James Okafor",
    excerpt: "We're excited to announce a new partnership with the Fayette County School District, expanding our digital literacy programming to five additional schools this semester.",
    content: `DSSN is thrilled to announce a new partnership with the Fayette County Public Schools system, bringing our Digital Skills Workshops to five additional schools beginning this spring semester.

The partnership will serve over 600 students in grades 6–12 with monthly workshops covering digital literacy, internet safety, coding basics, and career-readiness technology skills.

"Our students need these skills to compete in a digital economy," said a Fayette County administrator. "DSSN brings the expertise, the energy, and — importantly — the equipment."

Each participating school will also receive a cohort of 20 refurbished laptops for their Media Center, ensuring students have access even outside of workshop hours.

This expansion is made possible by the generous support of our donors and a capacity-building grant from a regional foundation. We are grateful, and we are just getting started.`,
    image: null,
    published: true,
  },
]

export const GALLERY_IMAGES = [
  { id: 1, caption: "Laptop distribution event at Lincoln Elementary", category: "Events" },
  { id: 2, caption: "Students in our Digital Skills Workshop", category: "Programs" },
  { id: 3, caption: "Teacher Professional Development Day", category: "Programs" },
  { id: 4, caption: "Scholarship award ceremony 2023", category: "Events" },
  { id: 5, caption: "College campus visit with DSSN students", category: "Programs" },
  { id: 6, caption: "DSSN Wellness Circle at the community center", category: "Wellness" },
  { id: 7, caption: "Volunteer laptop refurbishment session", category: "Volunteers" },
  { id: 8, caption: "Board members and staff at annual gala", category: "Events" },
  { id: 9, caption: "Students receiving diplomas", category: "Events" },
  { id: 10, caption: "Dr. Worthington at community outreach", category: "Programs" },
  { id: 11, caption: "DSSN coding bootcamp for high schoolers", category: "Programs" },
  { id: 12, caption: "Annual fundraising gala 2023", category: "Events" },
]
