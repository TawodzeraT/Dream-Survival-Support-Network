import React from 'react'
import ProgramPage from './ProgramPage'
export default function Scholarships() { return <ProgramPage programId="scholarships" /> }
