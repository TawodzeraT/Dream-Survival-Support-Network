import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Heart, CheckCircle } from 'lucide-react'
import { useSite } from '../context/SiteContext'
import './ProgramPage.css'

export default function ProgramPage({ programId }) {
  const { programs } = useSite()
  const program = programs.find(p => p.id === programId)

  useEffect(() => { window.scrollTo(0, 0) }, [programId])

  if (!program) return <div className="container" style={{ padding: '80px 24px' }}>Program not found.</div>

  return (
    <div className="program-page">
      {/* Hero */}
      <div className="page-hero" style={{ '--accent': program.color }}>
        <div className="page-hero__accent-circle" />
        <div className="container">
          <div className="program-page__hero-icon">{program.icon}</div>
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            DSSN Programs
          </span>
          <h1>{program.title}</h1>
          <p>{program.tagline}</p>
        </div>
      </div>

      {/* Stats bar */}
      <div className="program-page__stats-bar">
        <div className="container program-page__stats-inner">
          {program.stats.map(s => (
            <div key={s.label} className="program-page__stat">
              <strong>{s.value}</strong>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <section className="section-padding">
        <div className="container program-page__body">
          <div className="program-page__content">
            <h2>About This Program</h2>
            <div className="program-page__desc">
              {program.description.split('\n\n').map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>

            {/* Impact */}
            <div className="program-page__impact">
              <CheckCircle size={20} />
              <p><strong>Your Impact:</strong> {program.impact}</p>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="program-page__sidebar">
            <div className="program-page__sidebar-card">
              <h3>Support This Program</h3>
              <p>Your donation directly funds this program and the students and families we serve.</p>
              <Link to="/donate" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 16 }}>
                <Heart size={16} /> Donate Now
              </Link>
              <Link to="/contact" className="btn btn-outline-dark" style={{ width: '100%', justifyContent: 'center', marginTop: 10 }}>
                Partner With Us
              </Link>
            </div>

            <div className="program-page__sidebar-programs">
              <h4>Other Programs</h4>
              {/* This will be filled by the page — see below */}
              <ul>
                {[
                  { id: 'digital-learning', label: 'Digital Learning', icon: '💻' },
                  { id: 'teacher-support', label: 'Teacher Support', icon: '🏫' },
                  { id: 'scholarships', label: 'Scholarships', icon: '🎓' },
                  { id: 'college-readiness', label: 'College Readiness', icon: '📚' },
                  { id: 'wellness', label: 'Wellness', icon: '💙' },
                ].filter(p => p.id !== programId).map(p => (
                  <li key={p.id}>
                    <Link to={`/${p.id}`}>
                      <span>{p.icon}</span>
                      {p.label}
                      <ArrowRight size={13} />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </section>

      {/* CTA */}
      <section className="program-page__cta">
        <div className="container program-page__cta-inner">
          <div>
            <h2>Make a Difference Today</h2>
            <p>Every contribution, no matter the size, creates real change in our community.</p>
          </div>
          <Link to="/donate" className="btn btn-primary btn-lg">
            <Heart size={18} /> Donate Now
          </Link>
        </div>
      </section>
    </div>
  )
}
