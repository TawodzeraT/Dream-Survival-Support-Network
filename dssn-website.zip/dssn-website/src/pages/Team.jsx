import React, { useEffect } from 'react'
import { useSite } from '../context/SiteContext'
import { Link } from 'react-router-dom'
import { Heart } from 'lucide-react'
import './Team.css'

export default function Team() {
  const { team } = useSite()
  useEffect(() => { window.scrollTo(0, 0) }, [])

  const founder = team[0]
  const others = team.slice(1)

  return (
    <div className="team-page">
      {/* Hero */}
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            Our People
          </span>
          <h1>The Team Behind DSSN</h1>
          <p>Passionate leaders committed to building hope and opportunity for every dreamer and survivor we serve.</p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container">
          {/* Founder Feature */}
          {founder && (
            <div className="team-founder">
              <div className="team-founder__avatar">
                {founder.image
                  ? <img src={founder.image} alt={founder.name} />
                  : <div className="team-founder__initials">{founder.initials}</div>
                }
              </div>
              <div className="team-founder__info">
                <span className="section-label">Founder & Leader</span>
                <h2>{founder.name}</h2>
                <p className="team-founder__title">{founder.title}</p>
                <p className="team-founder__bio">{founder.bio}</p>
              </div>
            </div>
          )}

          {/* Board + Staff */}
          <div className="section-header mt-48" style={{ marginBottom: 36 }}>
            <span className="section-label">Board & Staff</span>
            <h2 className="text-h2">Leadership Team</h2>
          </div>

          <div className="team-grid">
            {others.map(member => (
              <div key={member.id} className="team-card">
                <div className="team-card__avatar">
                  {member.image
                    ? <img src={member.image} alt={member.name} />
                    : <div className="team-card__initials">{member.initials}</div>
                  }
                </div>
                <h3 className="team-card__name">{member.name}</h3>
                <p className="team-card__title">{member.title}</p>
                <p className="team-card__bio">{member.bio}</p>
              </div>
            ))}
          </div>

          {/* Join CTA */}
          <div className="team-cta">
            <h3>Join Our Mission</h3>
            <p>Interested in volunteering, partnering, or joining our board? We'd love to hear from you.</p>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/contact" className="btn btn-primary btn-lg">
                Get in Touch
              </Link>
              <Link to="/donate" className="btn btn-outline-dark btn-lg">
                <Heart size={16} /> Donate
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
