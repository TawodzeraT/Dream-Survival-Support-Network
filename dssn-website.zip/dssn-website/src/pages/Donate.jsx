import React, { useState, useEffect } from 'react'
import { Heart, CreditCard, Check, Laptop, Gift, Users, BookOpen } from 'lucide-react'
import { DONATION_TIERS } from '../data/siteData'
import './Donate.css'

const CUSTOM_AMOUNTS = [25, 50, 100, 250, 500]

export default function Donate() {
  const [selectedTier, setSelectedTier] = useState(null)
  const [customAmount, setCustomAmount] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('card')
  const [frequency, setFrequency] = useState('once')
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', cardNumber: '', expiry: '', cvv: '' })

  useEffect(() => { window.scrollTo(0, 0) }, [])

  const selectedAmount = selectedTier
    ? DONATION_TIERS.find(t => t.id === selectedTier)?.amount
    : customAmount
      ? Number(customAmount)
      : null

  const handleTierSelect = (tier) => {
    setSelectedTier(tier.id)
    setCustomAmount('')
  }

  const handleCustom = (e) => {
    setCustomAmount(e.target.value)
    setSelectedTier(null)
  }

  const handleQuick = (amt) => {
    setCustomAmount(String(amt))
    setSelectedTier(null)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!selectedAmount || !form.email) return
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="donate-success">
        <div className="donate-success__card">
          <div className="donate-success__icon">🎉</div>
          <h2>Thank You!</h2>
          <p className="donate-success__amount">
            ${selectedAmount?.toLocaleString()} donated
          </p>
          <p>Your generosity is making a real difference. You'll receive a confirmation email at <strong>{form.email}</strong> shortly.</p>
          <p style={{ marginTop: 12, fontSize: '0.9rem', color: 'var(--gray-text)' }}>
            DSSN is a 501(c)(3) organization. Your donation is tax-deductible. EIN: 12-3456789
          </p>
          <button className="btn btn-primary mt-24" onClick={() => setSubmitted(false)}>
            Make Another Donation
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="donate-page">
      {/* Page Hero */}
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            Support Our Mission
          </span>
          <h1>Donate Now</h1>
          <p>Every dollar you give goes directly to students, educators, and families who need it most.</p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container donate-layout">

          {/* LEFT — Donation Tiers & Impact */}
          <div className="donate-left">
            <h2 className="donate-left__title">Choose Your Impact</h2>

            {/* Donation Tiers */}
            <div className="donate-tiers">
              {DONATION_TIERS.map(tier => (
                <button
                  key={tier.id}
                  className={`donate-tier ${selectedTier === tier.id ? 'donate-tier--active' : ''} ${tier.featured ? 'donate-tier--featured' : ''}`}
                  onClick={() => handleTierSelect(tier)}
                >
                  {tier.featured && <span className="donate-tier__badge">Most Popular</span>}
                  <div className="donate-tier__top">
                    <span className="donate-tier__icon">{tier.icon}</span>
                    <div>
                      <div className="donate-tier__amount">${tier.amount}</div>
                      <div className="donate-tier__label">{tier.label}</div>
                    </div>
                    {selectedTier === tier.id && <Check size={18} className="donate-tier__check" />}
                  </div>
                  <p className="donate-tier__desc">{tier.description}</p>
                </button>
              ))}
            </div>

            {/* Quick amounts */}
            <div className="donate-quick">
              <p className="donate-quick__label">Or choose a quick amount:</p>
              <div className="donate-quick__amounts">
                {CUSTOM_AMOUNTS.map(amt => (
                  <button
                    key={amt}
                    className={`donate-quick__btn ${customAmount === String(amt) ? 'donate-quick__btn--active' : ''}`}
                    onClick={() => handleQuick(amt)}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom input */}
            <div className="donate-custom">
              <label className="form-label">Custom Amount</label>
              <div className="donate-custom__input-wrap">
                <span className="donate-custom__dollar">$</span>
                <input
                  type="number"
                  min="1"
                  value={customAmount}
                  onChange={handleCustom}
                  className="form-input donate-custom__input"
                  placeholder="Enter any amount"
                />
              </div>
            </div>

            {/* Impact info */}
            <div className="donate-impact">
              <h4>🎯 Where Your Money Goes</h4>
              <div className="donate-impact__items">
                {[
                  { icon: <Laptop size={16} />, label: 'Technology Access', pct: 55 },
                  { icon: <Users size={16} />, label: 'Programs & Staffing', pct: 30 },
                  { icon: <BookOpen size={16} />, label: 'Scholarships', pct: 10 },
                  { icon: <Gift size={16} />, label: 'Operations', pct: 5 },
                ].map(item => (
                  <div key={item.label} className="donate-impact__item">
                    <div className="donate-impact__item-header">
                      {item.icon}
                      <span>{item.label}</span>
                      <strong>{item.pct}%</strong>
                    </div>
                    <div className="donate-impact__bar">
                      <div className="donate-impact__fill" style={{ width: `${item.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT — Computer-Shaped Form */}
          <div className="donate-right">
            <div className="computer">
              {/* Monitor */}
              <div className="computer__monitor">
                <div className="computer__screen">
                  {/* Screen header */}
                  <div className="computer__screen-header">
                    <div className="computer__screen-dots">
                      <span /><span style={{ background: '#facc15' }} /><span style={{ background: '#4ade80' }} />
                    </div>
                    <span className="computer__screen-title">DSSN Secure Donation Portal</span>
                    <span className="computer__screen-lock">🔒 SSL</span>
                  </div>

                  {/* Screen content = form */}
                  <div className="computer__screen-body">
                    {/* Summary */}
                    {selectedAmount && (
                      <div className="donate-form__summary">
                        <span>Donating:</span>
                        <strong>${selectedAmount.toLocaleString()}</strong>
                        {selectedTier && (
                          <span className="donate-form__tier-label">
                            {DONATION_TIERS.find(t => t.id === selectedTier)?.label}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Frequency */}
                    <div className="donate-form__frequency">
                      {['once', 'monthly', 'annually'].map(f => (
                        <button
                          key={f}
                          className={`donate-form__freq-btn ${frequency === f ? 'donate-form__freq-btn--active' : ''}`}
                          onClick={() => setFrequency(f)}
                          type="button"
                        >
                          {f === 'once' ? 'One-Time' : f.charAt(0).toUpperCase() + f.slice(1)}
                        </button>
                      ))}
                    </div>

                    <form onSubmit={handleSubmit}>
                      {/* Payment Method */}
                      <div className="donate-form__payment-methods">
                        {[
                          { id: 'card', label: 'Card', icon: '💳' },
                          { id: 'paypal', label: 'PayPal', icon: '🅿️' },
                          { id: 'square', label: 'Square', icon: '⬛' },
                        ].map(m => (
                          <button
                            key={m.id}
                            type="button"
                            className={`donate-form__method ${paymentMethod === m.id ? 'donate-form__method--active' : ''}`}
                            onClick={() => setPaymentMethod(m.id)}
                          >
                            {m.icon} {m.label}
                          </button>
                        ))}
                      </div>

                      {/* Personal Info */}
                      <div className="donate-form__row">
                        <div className="form-group">
                          <label className="form-label">First Name *</label>
                          <input
                            className="form-input"
                            required
                            value={form.firstName}
                            onChange={e => setForm({ ...form, firstName: e.target.value })}
                            placeholder="Jane"
                          />
                        </div>
                        <div className="form-group">
                          <label className="form-label">Last Name *</label>
                          <input
                            className="form-input"
                            required
                            value={form.lastName}
                            onChange={e => setForm({ ...form, lastName: e.target.value })}
                            placeholder="Smith"
                          />
                        </div>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Email Address *</label>
                        <input
                          type="email"
                          className="form-input"
                          required
                          value={form.email}
                          onChange={e => setForm({ ...form, email: e.target.value })}
                          placeholder="jane@email.com"
                        />
                      </div>

                      {/* Card Fields */}
                      {paymentMethod === 'card' && (
                        <>
                          <div className="form-group">
                            <label className="form-label">Card Number</label>
                            <input
                              className="form-input"
                              value={form.cardNumber}
                              onChange={e => setForm({ ...form, cardNumber: e.target.value })}
                              placeholder="1234 5678 9012 3456"
                              maxLength={19}
                            />
                          </div>
                          <div className="donate-form__row">
                            <div className="form-group">
                              <label className="form-label">Expiry</label>
                              <input className="form-input" placeholder="MM/YY" maxLength={5}
                                value={form.expiry}
                                onChange={e => setForm({ ...form, expiry: e.target.value })} />
                            </div>
                            <div className="form-group">
                              <label className="form-label">CVV</label>
                              <input className="form-input" placeholder="123" maxLength={4}
                                value={form.cvv}
                                onChange={e => setForm({ ...form, cvv: e.target.value })} />
                            </div>
                          </div>
                        </>
                      )}

                      {paymentMethod === 'paypal' && (
                        <div className="donate-form__paypal">
                          <p>You'll be redirected to PayPal to complete your donation securely.</p>
                        </div>
                      )}

                      {paymentMethod === 'square' && (
                        <div className="donate-form__paypal">
                          <p>You'll be redirected to Square to complete your donation securely.</p>
                        </div>
                      )}

                      <button
                        type="submit"
                        className="btn btn-primary"
                        style={{ width: '100%', justifyContent: 'center', padding: '15px', fontSize: '1rem' }}
                        disabled={!selectedAmount}
                      >
                        <Heart size={18} />
                        {selectedAmount ? `Donate $${selectedAmount.toLocaleString()} ${frequency === 'once' ? '' : frequency}` : 'Select an Amount'}
                      </button>

                      <p className="donate-form__disclaimer">
                        🔒 Secured with 256-bit SSL encryption. DSSN is a 501(c)(3) nonprofit — EIN: 12-3456789. Your donation is tax-deductible.
                      </p>
                    </form>
                  </div>
                </div>

                {/* Monitor stand details */}
                <div className="computer__bezel" />
              </div>

              {/* Stand */}
              <div className="computer__neck" />
              <div className="computer__base" />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
