import React, { useState, useEffect } from 'react'
import { Mail, MapPin, Phone, Send, CheckCircle } from 'lucide-react'
import { SITE_CONFIG } from '../data/siteData'
import './Contact.css'

export default function Contact() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  useEffect(() => { window.scrollTo(0, 0) }, [])

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setSubmitted(true)
    }, 1200)
  }

  return (
    <div className="contact-page">
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            Get In Touch
          </span>
          <h1>Contact DSSN</h1>
          <p>Whether you want to donate, volunteer, partner, or just say hello — we'd love to hear from you.</p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container contact-layout">
          {/* Left — Info */}
          <div className="contact-info">
            <h2>Let's Connect</h2>
            <p className="contact-info__intro">
              Our team typically responds within 1–2 business days. For urgent matters, please call us directly.
            </p>

            <div className="contact-info__items">
              <div className="contact-info__item">
                <div className="contact-info__icon">
                  <Mail size={20} />
                </div>
                <div>
                  <strong>Email</strong>
                  <a href={`mailto:${SITE_CONFIG.email}`}>{SITE_CONFIG.email}</a>
                </div>
              </div>
              <div className="contact-info__item">
                <div className="contact-info__icon">
                  <MapPin size={20} />
                </div>
                <div>
                  <strong>Address</strong>
                  <span>{SITE_CONFIG.address}</span>
                </div>
              </div>
              <div className="contact-info__item">
                <div className="contact-info__icon">
                  <Phone size={20} />
                </div>
                <div>
                  <strong>Phone</strong>
                  <a href={`tel:${SITE_CONFIG.phone}`}>{SITE_CONFIG.phone}</a>
                </div>
              </div>
            </div>

            <div className="contact-info__hours">
              <h4>Office Hours</h4>
              <p>Monday – Friday: 9:00 AM – 5:00 PM EST</p>
              <p>Saturday: By appointment</p>
              <p>Sunday: Closed</p>
            </div>

            <div className="contact-info__ways">
              <h4>Ways to Get Involved</h4>
              <ul>
                <li>💻 Donate a laptop or tech equipment</li>
                <li>🤝 Volunteer your time or skills</li>
                <li>🏢 Become a corporate partner</li>
                <li>🎓 Sponsor a scholarship</li>
                <li>📢 Share our mission</li>
              </ul>
            </div>
          </div>

          {/* Right — Form */}
          <div className="contact-form-wrap">
            {submitted ? (
              <div className="contact-success">
                <CheckCircle size={48} />
                <h3>Message Sent!</h3>
                <p>Thank you for reaching out. We'll get back to you within 1–2 business days at <strong>{form.email}</strong>.</p>
                <button className="btn btn-outline-dark mt-16" onClick={() => setSubmitted(false)}>
                  Send Another Message
                </button>
              </div>
            ) : (
              <form className="contact-form" onSubmit={handleSubmit}>
                <h3>Send Us a Message</h3>

                <div className="contact-form__row">
                  <div className="form-group">
                    <label className="form-label" htmlFor="firstName">First Name *</label>
                    <input
                      id="firstName"
                      name="firstName"
                      className="form-input"
                      required
                      value={form.firstName}
                      onChange={handleChange}
                      placeholder="Jane"
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="lastName">Last Name *</label>
                    <input
                      id="lastName"
                      name="lastName"
                      className="form-input"
                      required
                      value={form.lastName}
                      onChange={handleChange}
                      placeholder="Smith"
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="email">Email Address *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    className="form-input"
                    required
                    value={form.email}
                    onChange={handleChange}
                    placeholder="jane@email.com"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="subject">Subject</label>
                  <select
                    id="subject"
                    name="subject"
                    className="form-select"
                    value={form.subject}
                    onChange={handleChange}
                  >
                    <option value="">Select a topic...</option>
                    <option value="donation">Make a Donation</option>
                    <option value="volunteer">Volunteer Opportunities</option>
                    <option value="partnership">Corporate Partnership</option>
                    <option value="scholarship">Scholarship Inquiry</option>
                    <option value="media">Media / Press</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label" htmlFor="message">Message *</label>
                  <textarea
                    id="message"
                    name="message"
                    className="form-textarea"
                    required
                    rows={5}
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Tell us how we can help, or how you'd like to help us..."
                  />
                </div>

                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ width: '100%', justifyContent: 'center', padding: '15px' }}
                  disabled={loading}
                >
                  {loading ? 'Sending...' : <><Send size={16} /> Send Message</>}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
