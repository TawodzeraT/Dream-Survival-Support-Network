// DigitalLearning.jsx
import React from 'react'
import ProgramPage from './ProgramPage'
export default function DigitalLearning() {
  return <ProgramPage programId="digital-learning" />
}
