import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Calendar, User, ArrowRight } from 'lucide-react'
import { useSite } from '../context/SiteContext'
import './Blog.css'

const CATEGORIES = ['All', 'Impact', 'Student Stories', 'News', 'Programs']

export default function Blog() {
  const { posts } = useSite()
  const [activeCategory, setActiveCategory] = useState('All')
  useEffect(() => { window.scrollTo(0, 0) }, [])

  const published = posts.filter(p => p.published)
  const filtered = activeCategory === 'All'
    ? published
    : published.filter(p => p.category === activeCategory)

  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })

  return (
    <div className="blog-page">
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            DSSN News
          </span>
          <h1>Stories & Updates</h1>
          <p>Read about our impact, student stories, program updates, and community news.</p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container">
          {/* Category Filter */}
          <div className="blog-filters">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                className={`blog-filter-btn ${activeCategory === cat ? 'blog-filter-btn--active' : ''}`}
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Featured Post */}
          {filtered.length > 0 && (
            <div className="blog-featured">
              <div className="blog-featured__meta">
                <span className="badge badge-blue">{filtered[0].category}</span>
                <span className="blog-meta"><Calendar size={13} /> {formatDate(filtered[0].date)}</span>
                <span className="blog-meta"><User size={13} /> {filtered[0].author}</span>
              </div>
              <h2 className="blog-featured__title">
                <Link to={`/blog/${filtered[0].slug}`}>{filtered[0].title}</Link>
              </h2>
              <p className="blog-featured__excerpt">{filtered[0].excerpt}</p>
              <Link to={`/blog/${filtered[0].slug}`} className="btn btn-primary">
                Read Full Story <ArrowRight size={16} />
              </Link>
            </div>
          )}

          {/* Post Grid */}
          <div className="blog-grid">
            {filtered.slice(1).map(post => (
              <article key={post.id} className="blog-card">
                <div className="blog-card__top">
                  <span className="badge badge-blue">{post.category}</span>
                </div>
                <h3 className="blog-card__title">
                  <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                </h3>
                <p className="blog-card__excerpt">{post.excerpt}</p>
                <div className="blog-card__footer">
                  <div className="blog-card__meta">
                    <span><Calendar size={12} /> {formatDate(post.date)}</span>
                    <span><User size={12} /> {post.author}</span>
                  </div>
                  <Link to={`/blog/${post.slug}`} className="blog-card__link">
                    Read <ArrowRight size={14} />
                  </Link>
                </div>
              </article>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="blog-empty">
              <p>No posts in this category yet.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
