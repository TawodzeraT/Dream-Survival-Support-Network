import React, { useEffect } from 'react'
import { useParams, Link, Navigate } from 'react-router-dom'
import { Calendar, User, ArrowLeft, Heart } from 'lucide-react'
import { useSite } from '../context/SiteContext'

export default function BlogPost() {
  const { slug } = useParams()
  const { posts } = useSite()
  useEffect(() => { window.scrollTo(0, 0) }, [slug])

  const post = posts.find(p => p.slug === slug && p.published)
  if (!post) return <Navigate to="/blog" replace />

  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })

  return (
    <div>
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            {post.category}
          </span>
          <h1 style={{ maxWidth: 700, margin: '0 auto 16px' }}>{post.title}</h1>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, color: 'rgba(255,255,255,0.7)', fontSize: '0.9rem' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Calendar size={14} /> {formatDate(post.date)}
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <User size={14} /> {post.author}
            </span>
          </div>
        </div>
      </div>

      <section className="section-padding">
        <div className="container" style={{ maxWidth: 760, margin: '0 auto' }}>
          <Link to="/blog" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--blue-primary)', fontWeight: 600, fontSize: '0.9rem', marginBottom: 32, textDecoration: 'none' }}>
            <ArrowLeft size={16} /> Back to News
          </Link>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {post.content.split('\n\n').map((para, i) => (
              <p key={i} style={{ fontSize: '1.05rem', color: 'var(--gray-dark)', lineHeight: 1.85 }}>{para}</p>
            ))}
          </div>

          {/* CTA */}
          <div className="highlight-box mt-32">
            <h3 style={{ marginBottom: 8, fontSize: '1.1rem' }}>Support Our Work</h3>
            <p style={{ color: 'var(--gray-text)', marginBottom: 16, fontSize: '0.95rem' }}>
              Stories like these are made possible by donors like you. Every contribution changes lives.
            </p>
            <Link to="/donate" className="btn btn-primary">
              <Heart size={16} /> Donate Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
