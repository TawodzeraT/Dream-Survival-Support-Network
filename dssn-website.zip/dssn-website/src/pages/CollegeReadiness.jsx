import React from 'react'
import ProgramPage from './ProgramPage'
export default function CollegeReadiness() { return <ProgramPage programId="college-readiness" /> }
