import React, { useState, useEffect } from 'react'
import { X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react'
import { useSite } from '../context/SiteContext'
import './Gallery.css'

const CATEGORIES = ['All', 'Events', 'Programs', 'Wellness', 'Volunteers']

// Placeholder colors for demo images
const COLORS = [
  '#dbeafe', '#bfdbfe', '#93c5fd', '#60a5fa',
  '#e0e7ff', '#c7d2fe', '#a5b4fc', '#818cf8',
  '#eff6ff', '#dbeafe',
]

const EMOJIS = ['🎓', '💻', '📚', '🏫', '💙', '🤝', '🌟', '🎉', '👩‍🎓', '🖥️', '🎯', '📸']

export default function Gallery() {
  const { gallery } = useSite()
  const [activeCategory, setActiveCategory] = useState('All')
  const [lightboxIdx, setLightboxIdx] = useState(null)
  useEffect(() => { window.scrollTo(0, 0) }, [])

  // Keyboard navigation
  useEffect(() => {
    if (lightboxIdx === null) return
    const handler = (e) => {
      if (e.key === 'Escape') setLightboxIdx(null)
      if (e.key === 'ArrowRight') setLightboxIdx(i => (i + 1) % filtered.length)
      if (e.key === 'ArrowLeft') setLightboxIdx(i => (i - 1 + filtered.length) % filtered.length)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [lightboxIdx])

  const filtered = activeCategory === 'All'
    ? gallery
    : gallery.filter(img => img.category === activeCategory)

  const openLightbox = (idx) => {
    setLightboxIdx(idx)
    document.body.style.overflow = 'hidden'
  }

  const closeLightbox = () => {
    setLightboxIdx(null)
    document.body.style.overflow = ''
  }

  return (
    <div className="gallery-page">
      <div className="page-hero">
        <div className="container">
          <span className="section-label" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff' }}>
            Visual Stories
          </span>
          <h1>Gallery</h1>
          <p>Moments of impact, community, and hope from across our programs and events.</p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container">
          {/* Category Filter */}
          <div className="gallery-filters">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                className={`blog-filter-btn ${activeCategory === cat ? 'blog-filter-btn--active' : ''}`}
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </button>
            ))}
            <span className="gallery-count">{filtered.length} photos</span>
          </div>

          {/* Masonry Grid */}
          <div className="gallery-grid">
            {filtered.map((img, idx) => (
              <div
                key={img.id}
                className="gallery-item"
                onClick={() => openLightbox(idx)}
                role="button"
                tabIndex={0}
                onKeyDown={e => e.key === 'Enter' && openLightbox(idx)}
                aria-label={`View: ${img.caption}`}
              >
                {img.url ? (
                  <img src={img.url} alt={img.caption} loading="lazy" />
                ) : (
                  <div
                    className="gallery-item__placeholder"
                    style={{ background: COLORS[img.id % COLORS.length] }}
                  >
                    <span>{EMOJIS[img.id % EMOJIS.length]}</span>
                  </div>
                )}
                <div className="gallery-item__overlay">
                  <ZoomIn size={24} />
                  <p>{img.caption}</p>
                </div>
                <span className="gallery-item__category">{img.category}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxIdx !== null && (
        <div className="lightbox" onClick={closeLightbox}>
          <button className="lightbox__close" onClick={closeLightbox} aria-label="Close">
            <X size={24} />
          </button>

          <button
            className="lightbox__nav lightbox__nav--prev"
            onClick={e => { e.stopPropagation(); setLightboxIdx(i => (i - 1 + filtered.length) % filtered.length) }}
            aria-label="Previous"
          >
            <ChevronLeft size={28} />
          </button>

          <div className="lightbox__content" onClick={e => e.stopPropagation()}>
            {filtered[lightboxIdx]?.url ? (
              <img src={filtered[lightboxIdx].url} alt={filtered[lightboxIdx].caption} />
            ) : (
              <div
                className="lightbox__placeholder"
                style={{ background: COLORS[filtered[lightboxIdx]?.id % COLORS.length] }}
              >
                <span>{EMOJIS[filtered[lightboxIdx]?.id % EMOJIS.length]}</span>
              </div>
            )}
            <div className="lightbox__caption">
              <p>{filtered[lightboxIdx]?.caption}</p>
              <span className="badge badge-blue">{filtered[lightboxIdx]?.category}</span>
            </div>
          </div>

          <button
            className="lightbox__nav lightbox__nav--next"
            onClick={e => { e.stopPropagation(); setLightboxIdx(i => (i + 1) % filtered.length) }}
            aria-label="Next"
          >
            <ChevronRight size={28} />
          </button>

          <div className="lightbox__counter">
            {lightboxIdx + 1} / {filtered.length}
          </div>
        </div>
      )}
    </div>
  )
}
