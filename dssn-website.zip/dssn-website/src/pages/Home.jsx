import React, { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Heart, Users, Laptop, Star, CheckCircle } from 'lucide-react'
import ImpactCounter from '../components/ImpactCounter'
import { PROGRAMS, MISSION } from '../data/siteData'
import './Home.css'

function AnimatedSection({ children, className = '', delay = 0 }) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true) },
      { threshold: 0.1 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      className={`${className} ${visible ? 'anim-visible' : 'anim-hidden'}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  )
}

export default function Home() {
  useEffect(() => { window.scrollTo(0, 0) }, [])

  return (
    <div className="home">
      {/* ── HERO ── */}
      <section className="hero hero-gradient">
        <div className="hero__bg-grid" aria-hidden />
        <div className="container hero__inner">
          <div className="hero__content">
            <div className="hero__badge">
              <span className="hero__badge-dot" />
              Serving Kentucky & Beyond Since 2017
            </div>
            <h1 className="hero__headline">
              Together<br />
              <span className="hero__headline-highlight">We Build Hope!</span>
            </h1>
            <p className="hero__sub">
              The Dreamers and Survivors Support Network empowers underserved youth and families through digital access, scholarships, and community-driven programs that turn dreams into reality.
            </p>
            <div className="hero__actions">
              <Link to="/donate" className="btn btn-primary btn-lg">
                <Heart size={18} /> Donate Now
              </Link>
              <Link to="/digital-learning" className="btn btn-outline btn-lg">
                Our Programs <ArrowRight size={18} />
              </Link>
            </div>

            {/* Quick stats row */}
            <div className="hero__stats">
              <div className="hero__stat">
                <strong>847+</strong>
                <span>Laptops Donated</span>
              </div>
              <div className="hero__stat-divider" />
              <div className="hero__stat">
                <strong>2,400+</strong>
                <span>Students Reached</span>
              </div>
              <div className="hero__stat-divider" />
              <div className="hero__stat">
                <strong>130+</strong>
                <span>Scholarships Awarded</span>
              </div>
            </div>
          </div>

          {/* Hero visual */}
          <div className="hero__visual">
            <div className="hero__card-stack">
              <div className="hero__card hero__card--back" />
              <div className="hero__card hero__card--mid" />
              <div className="hero__card hero__card--front">
                <div className="hero__card-content">
                  <div className="hero__card-icon">💻</div>
                  <div className="hero__card-label">Latest Donation</div>
                  <div className="hero__card-value">$600</div>
                  <div className="hero__card-desc">Bulk laptop shipment<br />to Lincoln Elementary</div>
                  <div className="hero__card-tag">
                    <CheckCircle size={13} /> Delivered — March 2024
                  </div>
                </div>
              </div>
            </div>

            {/* Floating chips */}
            <div className="hero__chip hero__chip--1">
              <span>🎓</span> 94% College Acceptance Rate
            </div>
            <div className="hero__chip hero__chip--2">
              <Laptop size={14} /> 847 Laptops & Counting
            </div>
          </div>
        </div>
      </section>

      {/* ── IMPACT COUNTER ── */}
      <ImpactCounter />

      {/* ── WHO WE ARE ── */}
      <section className="section-padding who-we-are">
        <div className="container">
          <div className="who-we-are__grid">
            <AnimatedSection className="who-we-are__left anim-slide">
              <span className="section-label">Who We Are</span>
              <h2 className="text-h2">Born from Struggle,<br />Built on Belief</h2>
              <div className="divider" />
              <p className="text-lead" style={{ color: 'var(--gray-text)', marginBottom: 24 }}>
                DSSN was founded in 2017 by Dr. Angela Worthington — a survivor herself — after witnessing firsthand the systemic barriers that keep talented students from reaching their potential.
              </p>
              <p style={{ color: 'var(--gray-text)', marginBottom: 32 }}>
                What started as a car trunk full of refurbished laptops has grown into a full-service support network serving thousands of students, families, and educators across Kentucky and beyond.
              </p>
              <p style={{ color: 'var(--gray-text)', marginBottom: 36 }}>
                We believe that where you start should never determine where you finish. Every program we run, every laptop we donate, every scholarship we award is a direct investment in that belief.
              </p>
              <div className="who-we-are__values">
                {MISSION.values.map(v => (
                  <div key={v.title} className="who-we-are__value">
                    <CheckCircle size={16} className="who-we-are__value-icon" />
                    <div>
                      <strong>{v.title}</strong>
                      <span>{v.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </AnimatedSection>

            <AnimatedSection className="who-we-are__right anim-slide" delay={150}>
              <div className="who-we-are__image-block">
                <div className="who-we-are__img-main">
                  <div className="who-we-are__img-placeholder">
                    <span>👩‍🏫</span>
                    <p>Community Impact</p>
                  </div>
                </div>
                <div className="who-we-are__img-badge">
                  <Star size={16} fill="currentColor" />
                  <div>
                    <strong>7 Years</strong>
                    <span>of Community Impact</span>
                  </div>
                </div>
                <div className="who-we-are__img-stat">
                  <Users size={18} />
                  <div>
                    <strong>2,400+ Students</strong>
                    <span>directly served</span>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* ── WHAT WE DO ── */}
      <section className="section-padding what-we-do">
        <div className="container">
          <AnimatedSection className="section-header text-center anim-up">
            <span className="section-label">What We Do</span>
            <h2 className="text-h2">Five Programs. One Mission.</h2>
            <p className="text-gray">We meet students and families where they are — and walk with them toward where they want to be.</p>
          </AnimatedSection>

          <div className="programs-grid">
            {PROGRAMS.map((program, i) => (
              <AnimatedSection key={program.id} className="program-card anim-up" delay={i * 80}>
                <div className="program-card__icon" style={{ background: `${program.color}15`, color: program.color }}>
                  {program.icon}
                </div>
                <h3 className="program-card__title">{program.title}</h3>
                <p className="program-card__summary">{program.summary}</p>
                <div className="program-card__stats">
                  {program.stats.slice(0, 2).map(s => (
                    <div key={s.label} className="program-card__stat">
                      <strong>{s.value}</strong>
                      <span>{s.label}</span>
                    </div>
                  ))}
                </div>
                <Link to={`/${program.id}`} className="program-card__link">
                  Learn More <ArrowRight size={15} />
                </Link>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHO WE SERVE ── */}
      <section className="section-padding who-we-serve">
        <div className="container">
          <AnimatedSection className="section-header text-center anim-up">
            <span className="section-label">Who We Serve</span>
            <h2 className="text-h2">Every Dreamer. Every Survivor.</h2>
            <p className="text-gray" style={{ maxWidth: 560, margin: '0 auto' }}>
              Our programs are designed for those who face the highest barriers and have the most to gain.
            </p>
          </AnimatedSection>

          <div className="serve-grid">
            {[
              { icon: '👦', label: 'K–12 Students', desc: 'From elementary through high school, providing technology and learning support.' },
              { icon: '🎓', label: 'First-Gen College Students', desc: 'Scholarships, mentorship, and college readiness for first-generation scholars.' },
              { icon: '🌍', label: 'Immigrant Families', desc: 'Resources and support for immigrant and refugee families navigating new systems.' },
              { icon: '👩‍🏫', label: 'Under-Resourced Teachers', desc: 'Professional development and classroom grants for educators in high-need schools.' },
              { icon: '🏠', label: 'Housing-Unstable Youth', desc: 'Wraparound support for youth experiencing homelessness or housing insecurity.' },
              { icon: '💙', label: 'Youth in Crisis', desc: 'Mental health resources and wellness support for young people navigating trauma.' },
            ].map((item, i) => (
              <AnimatedSection key={item.label} className="serve-card anim-up" delay={i * 60}>
                <span className="serve-card__icon">{item.icon}</span>
                <h4 className="serve-card__title">{item.label}</h4>
                <p className="serve-card__desc">{item.desc}</p>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA DONATE BANNER ── */}
      <section className="cta-banner">
        <div className="container">
          <AnimatedSection className="cta-banner__inner anim-up">
            <div className="cta-banner__text">
              <h2>Ready to Make a Difference?</h2>
              <p>Every dollar you give goes directly to students, families, and educators who need it most. No overhead. Maximum impact.</p>
              <ul className="cta-banner__list">
                <li><CheckCircle size={16} /> $40 = 1 laptop for a student</li>
                <li><CheckCircle size={16} /> $100 = 2 laptops donated</li>
                <li><CheckCircle size={16} /> $750 = full teacher workshop</li>
              </ul>
            </div>
            <div className="cta-banner__actions">
              <Link to="/donate" className="btn btn-primary btn-lg">
                <Heart size={18} /> Donate Now
              </Link>
              <Link to="/contact" className="btn btn-outline btn-lg">
                Partner With Us
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  )
}
