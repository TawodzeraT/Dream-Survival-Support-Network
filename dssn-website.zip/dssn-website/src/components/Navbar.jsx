import React, { useState, useEffect, useRef } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { Menu, X, ChevronDown, Heart } from 'lucide-react'
import './Navbar.css'

const PROGRAMS_MENU = [
  { path: '/digital-learning', label: 'Digital Learning', icon: '💻' },
  { path: '/teacher-support', label: 'Teacher Support', icon: '🏫' },
  { path: '/scholarships', label: 'Scholarships', icon: '🎓' },
  { path: '/college-readiness', label: 'College Readiness', icon: '📚' },
  { path: '/wellness', label: 'Wellness', icon: '💙' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [programsOpen, setProgramsOpen] = useState(false)
  const dropdownRef = useRef(null)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
    setProgramsOpen(false)
  }, [location])

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setProgramsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const isHomeDark = location.pathname === '/'

  return (
    <nav className={`navbar ${scrolled ? 'navbar--scrolled' : ''} ${isHomeDark && !scrolled ? 'navbar--dark' : ''}`}>
      <div className="container navbar__inner">
        {/* Logo */}
        <Link to="/" className="navbar__logo">
          <div className="navbar__logo-icon">
            <span>D</span>
          </div>
          <div className="navbar__logo-text">
            <span className="navbar__logo-name">DSSN</span>
            <span className="navbar__logo-tagline">Dreamers & Survivors</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <ul className="navbar__links">
          <li>
            <NavLink to="/" end className={({ isActive }) => isActive ? 'navbar__link navbar__link--active' : 'navbar__link'}>
              Home
            </NavLink>
          </li>

          {/* Programs Dropdown */}
          <li className="navbar__dropdown" ref={dropdownRef}>
            <button
              className={`navbar__link navbar__link-btn ${PROGRAMS_MENU.some(p => location.pathname === p.path) ? 'navbar__link--active' : ''}`}
              onClick={() => setProgramsOpen(o => !o)}
              aria-expanded={programsOpen}
            >
              Programs <ChevronDown size={14} className={`navbar__chevron ${programsOpen ? 'navbar__chevron--open' : ''}`} />
            </button>
            {programsOpen && (
              <div className="navbar__dropdown-menu">
                {PROGRAMS_MENU.map(item => (
                  <NavLink key={item.path} to={item.path} className="navbar__dropdown-item">
                    <span className="navbar__dropdown-icon">{item.icon}</span>
                    <span>{item.label}</span>
                  </NavLink>
                ))}
              </div>
            )}
          </li>

          <li>
            <NavLink to="/team" className={({ isActive }) => isActive ? 'navbar__link navbar__link--active' : 'navbar__link'}>
              Team
            </NavLink>
          </li>
          <li>
            <NavLink to="/blog" className={({ isActive }) => isActive ? 'navbar__link navbar__link--active' : 'navbar__link'}>
              News
            </NavLink>
          </li>
          <li>
            <NavLink to="/gallery" className={({ isActive }) => isActive ? 'navbar__link navbar__link--active' : 'navbar__link'}>
              Gallery
            </NavLink>
          </li>
          <li>
            <NavLink to="/contact" className={({ isActive }) => isActive ? 'navbar__link navbar__link--active' : 'navbar__link'}>
              Contact
            </NavLink>
          </li>
        </ul>

        {/* CTA */}
        <div className="navbar__actions">
          <Link to="/donate" className="btn btn-primary btn-sm navbar__donate-btn">
            <Heart size={14} />
            Donate
          </Link>
          <button
            className="navbar__mobile-toggle"
            onClick={() => setMenuOpen(o => !o)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="navbar__mobile-menu">
          <NavLink to="/" end className="navbar__mobile-link">Home</NavLink>
          <div className="navbar__mobile-section">
            <span className="navbar__mobile-section-label">Programs</span>
            {PROGRAMS_MENU.map(item => (
              <NavLink key={item.path} to={item.path} className="navbar__mobile-link navbar__mobile-link--sub">
                {item.icon} {item.label}
              </NavLink>
            ))}
          </div>
          <NavLink to="/team" className="navbar__mobile-link">Team</NavLink>
          <NavLink to="/blog" className="navbar__mobile-link">News</NavLink>
          <NavLink to="/gallery" className="navbar__mobile-link">Gallery</NavLink>
          <NavLink to="/contact" className="navbar__mobile-link">Contact</NavLink>
          <Link to="/donate" className="btn btn-primary mt-16" style={{ width: '100%', justifyContent: 'center' }}>
            <Heart size={16} /> Donate Now
          </Link>
        </div>
      )}
    </nav>
  )
}
