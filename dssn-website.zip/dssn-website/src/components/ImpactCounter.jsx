import React, { useEffect, useRef, useState } from 'react'
import { useSite } from '../context/SiteContext'
import './ImpactCounter.css'

function useCountUp(target, duration = 2000, start = false) {
  const [value, setValue] = useState(0)

  useEffect(() => {
    if (!start) return
    let startTime = null
    const startVal = 0

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3) // ease out cubic
      setValue(Math.floor(eased * (target - startVal) + startVal))
      if (progress < 1) requestAnimationFrame(animate)
    }

    requestAnimationFrame(animate)
  }, [target, duration, start])

  return value
}

function CounterBlock({ value, label, suffix = '', prefix = '' }) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)
  const animated = useCountUp(value, 2200, visible)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true) },
      { threshold: 0.3 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const displayVal = visible ? animated : 0

  return (
    <div className="counter-block" ref={ref}>
      <div className="counter-display">
        <span className="counter-prefix">{prefix}</span>
        <span className="counter-number">{displayVal.toLocaleString()}</span>
        <span className="counter-suffix">{suffix}</span>
      </div>
      <div className="counter-label">{label}</div>
      <div className="counter-bar" />
    </div>
  )
}

export default function ImpactCounter() {
  const { counter } = useSite()

  return (
    <section className="impact-counter">
      <div className="container">
        <div className="impact-counter__header">
          <span className="section-label">Our Impact</span>
          <h2 className="text-h2" style={{ color: '#fff' }}>Changing Lives, One Laptop at a Time</h2>
          <p style={{ color: 'rgba(255,255,255,0.7)', marginTop: 12, maxWidth: 520 }}>
            Every number represents a real person whose life was changed through community, technology, and education.
          </p>
        </div>

        {/* Digital display bar */}
        <div className="counter-screen">
          <div className="counter-screen__header">
            <span className="counter-screen__dot" />
            <span className="counter-screen__dot" style={{ background: '#facc15' }} />
            <span className="counter-screen__dot" style={{ background: '#4ade80' }} />
            <span className="counter-screen__title">DSSN IMPACT DASHBOARD — LIVE</span>
          </div>
          <div className="counter-screen__body">
            <div className="counter-grid">
              <CounterBlock value={counter.laptops} label="Laptops Donated" suffix="+" />
              <CounterBlock value={counter.students} label="Students Reached" suffix="+" />
              <CounterBlock value={counter.workshops} label="Workshops Hosted" suffix="+" />
              <CounterBlock value={counter.scholarships} label="Scholarships Awarded" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
