import React from 'react'
import { Link } from 'react-router-dom'
import { Mail, MapPin, Phone, Heart, ExternalLink } from 'lucide-react'
import { SITE_CONFIG } from '../data/siteData'
import './Footer.css'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer__top">
        <div className="container footer__grid">
          {/* Brand */}
          <div className="footer__brand">
            <div className="footer__logo">
              <div className="footer__logo-icon">D</div>
              <div>
                <div className="footer__logo-name">DSSN</div>
                <div className="footer__logo-sub">Dreamers & Survivors Support Network</div>
              </div>
            </div>
            <p className="footer__mission">
              Together We Build Hope! Empowering underserved youth and families through digital access, education, and community-driven programs.
            </p>
            <div className="footer__social">
              <a href={SITE_CONFIG.social.facebook} target="_blank" rel="noopener noreferrer" className="footer__social-link" aria-label="Facebook">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
              </a>
              <a href={SITE_CONFIG.social.twitter} target="_blank" rel="noopener noreferrer" className="footer__social-link" aria-label="Twitter/X">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4l16 16M4 20L20 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
              </a>
              <a href={SITE_CONFIG.social.instagram} target="_blank" rel="noopener noreferrer" className="footer__social-link" aria-label="Instagram">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" stroke="none"/></svg>
              </a>
              <a href={SITE_CONFIG.social.linkedin} target="_blank" rel="noopener noreferrer" className="footer__social-link" aria-label="LinkedIn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
              </a>
            </div>
          </div>

          {/* Programs */}
          <div className="footer__col">
            <h4 className="footer__col-title">Programs</h4>
            <ul className="footer__links">
              <li><Link to="/digital-learning">Digital Learning</Link></li>
              <li><Link to="/teacher-support">Teacher Support</Link></li>
              <li><Link to="/scholarships">Scholarships</Link></li>
              <li><Link to="/college-readiness">College Readiness</Link></li>
              <li><Link to="/wellness">Wellness</Link></li>
            </ul>
          </div>

          {/* Organization */}
          <div className="footer__col">
            <h4 className="footer__col-title">Organization</h4>
            <ul className="footer__links">
              <li><Link to="/team">Our Team</Link></li>
              <li><Link to="/blog">News & Blog</Link></li>
              <li><Link to="/gallery">Gallery</Link></li>
              <li><Link to="/contact">Contact</Link></li>
              <li><Link to="/donate">Donate</Link></li>
              <li><Link to="/admin/login" className="footer__admin-link">Admin Panel <ExternalLink size={11} /></Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="footer__col">
            <h4 className="footer__col-title">Contact</h4>
            <ul className="footer__contact">
              <li>
                <Mail size={15} />
                <a href={`mailto:${SITE_CONFIG.email}`}>{SITE_CONFIG.email}</a>
              </li>
              <li>
                <MapPin size={15} />
                <span>{SITE_CONFIG.address}</span>
              </li>
              <li>
                <Phone size={15} />
                <a href={`tel:${SITE_CONFIG.phone}`}>{SITE_CONFIG.phone}</a>
              </li>
            </ul>

            <Link to="/donate" className="footer__cta-btn">
              <Heart size={15} />
              Donate Now
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="footer__bottom">
        <div className="container footer__bottom-inner">
          <p>© {year} Dreamers and Survivors Support Network. All rights reserved.</p>
          <p>501(c)(3) Nonprofit Organization · EIN: 12-3456789</p>
        </div>
      </div>
    </footer>
  )
}
