# Dreamers and Survivors Support Network — Website

A full-featured nonprofit website for DSSN, built with React + Vite.

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## 🏗️ Build for Production

```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
src/
├── admin/                  # Admin panel
│   ├── AdminLogin.jsx      # Login page
│   ├── AdminDashboard.jsx  # Dashboard shell + sidebar
│   └── pages/
│       ├── AdminOverview.jsx     # Dashboard home
│       ├── AdminBlog.jsx         # Blog CRUD
│       ├── AdminGallery.jsx      # Gallery manager
│       ├── AdminDonations.jsx    # Impact counter editor
│       ├── AdminTeam.jsx         # Team member manager
│       ├── AdminPrograms.jsx     # Program page editor
│       └── AdminUsers.jsx        # Admin user management
├── components/
│   ├── Navbar.jsx / .css
│   ├── Footer.jsx / .css
│   └── ImpactCounter.jsx / .css
├── context/
│   ├── SiteContext.jsx     # All public content state (localStorage)
│   └── AdminContext.jsx    # Auth state (sessionStorage)
├── data/
│   └── siteData.js         # Initial seed data
└── pages/
    ├── Home.jsx             # Hero, counter, programs, CTA
    ├── ProgramPage.jsx      # Shared program template
    ├── DigitalLearning.jsx
    ├── TeacherSupport.jsx
    ├── Scholarships.jsx
    ├── CollegeReadiness.jsx
    ├── Wellness.jsx
    ├── Team.jsx
    ├── Donate.jsx           # Computer-shaped donation UI
    ├── Blog.jsx
    ├── BlogPost.jsx
    ├── Contact.jsx
    └── Gallery.jsx          # Lightbox gallery
```

## 🔐 Admin Panel

Access: `/admin/login`

| Username | Password    | Role  |
|----------|-------------|-------|
| admin    | dssn2024!   | Admin |
| editor   | editor2024  | Editor|

### Admin Features
- **Overview** — Live stats dashboard
- **Blog** — Create / edit / delete posts with preview
- **Gallery** — Add / remove gallery images by category
- **Donations & Counter** — Manually update impact numbers live
- **Team** — Add / edit / remove team members and board
- **Programs** — Edit all program page content
- **Users** — Create and manage admin accounts

## 🎨 Design System

| Token            | Value       |
|------------------|-------------|
| Blue Primary     | `#1a56db`   |
| Black            | `#050d1a`   |
| White            | `#ffffff`   |
| Font (Headings)  | Playfair Display |
| Font (Body)      | DM Sans     |
| Font (Counter)   | DM Mono     |

## 💰 Donation Tiers

| Amount | Impact                  |
|--------|-------------------------|
| $40    | 1 laptop for a student  |
| $100   | 2 laptops               |
| $600   | Bulk laptop shipment    |
| $750   | Full teacher workshop   |

## 📦 Tech Stack

- **React 18** + **React Router v6**
- **Vite** (build tool)
- **Lucide React** (icons)
- **Google Fonts** (Playfair Display, DM Sans, DM Mono)
- No external CSS framework — custom design system

## 🌐 Deployment

Deploy to **Vercel** (recommended):
1. Push to GitHub
2. Import in Vercel
3. Set Framework Preset → Vite
4. Deploy ✓

Or **Netlify**: drag & drop the `dist/` folder after `npm run build`.

## 📧 Contact Info (editable in `src/data/siteData.js`)

- Email: info@dreamsupport.org
- Address: 3888 Winthrop Dr, Lexington, KY 40514
